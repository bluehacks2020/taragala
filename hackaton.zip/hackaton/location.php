<?php 
    include_once 'class/adminCommand.php';

    $command = new adminCommand;
    $dataLoc = array();
    if(isset($_GET['loc']) AND !empty($_GET['loc']) AND is_numeric($_GET['loc'])){
        $dataLoc = adminCommand::getLocData($_GET['loc'], new adminCommand);
        
    }else{
        header('Location:../');
    }
?>

<!DOCTYPE html>
<html>
  <head>
  
    <title>Geolocation</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Bangers|Open+Sans+Condensed:300|Saira+Stencil+One|Varela+Round&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 0%;
      }
      /* Optional: Makes the sample page fill the window. */

      html, body {
        height: 100%;
        margin: 0px;
        padding: 0px;
        font-family: 'Open Sans Condensed', sans-serif;
      }

      nav{
          width:100%;
          box-shadow:0px 5px 10px 0px rgba(0,0,0,0.1);
          padding:0px 10%;
          position:fixed;
          top:0;
          left:0;
          z-index:10;
          background-color:white;
      }

      nav > table td{
          padding:10px;
          
          transition:0px;
      }
      nav > table td:not(.logo){
          text-align:center;
          cursor:pointer;
          -webkit-box-sizing: border-box;
          
      }
      nav > .pc td:not(.logo):hover{
        transition:0px;
        background-color:rgba(74, 110, 241, 0.41);
        color:white;
        border-bottom:3px solid #4B6FF0;
      }

      section{
         
          
      }

      .mainAct{
        padding:0px 10%;
        width:100%;
        height:100vh;
        /* border:1px solid red; */
        margin-top:5%;
        margin-bottom:40%;
        
      }

      .information{
          display:grid;
          grid-template-columns:1fr 4fr;
          background-color:rgba(74, 110, 241, 0.41);
      }

      .rightInfo{
          display:grid;
          grid-template-columns:4fr 1fr;
          
      }

      .rightInfo > div{
          background-position:center;
          background-size:100% 100%;
          background-repeat:no-repeat;

      }

      .leftInfo{
          display:grid;
          grid-template-columns:1fr 4fr;
      }

      .leftInfo > div{
          background-position:center;
          background-size:100% 100%;
          background-repeat:no-repeat;

      }

      .notifright{
          position:fixed;
          right:0%;
          top:20%;
      }
      

      .notifright > div{
          padding: 20px 15px ;
          border:1px solid rgba(0,0,0,0.1);
          color:white;
          cursor:pointer;
          transition:0.2s;
      }

      .notifright > div:hover{
          transition:0.2s;
          opacity:0.5;
      }

      .alertlocationoff{
          position:fixed;
          width:100%;
          height:100vh;
          padding:5% 22%;
          background-color:rgba(232, 37, 12, 0.56);
          top:0;
          left:0;
          z-index:15;
          overflow-y:scroll;
          visibility:hidden;
          opacity:0;
          transition:0.5s;
      }


      .alertlocationoff > div{
          background-color:white;
          padding:1em;
          border-radius:5px;
          border-top:5px solid #B71E0A;
      }
     

      





      .alertlocationon{
          position:fixed;
          width:100%;
          height:100vh;
          padding:5% 22%;
          background-color:rgba(232, 37, 12, 0.56);
          top:0;
          left:0;
          z-index:15;
          overflow-y:scroll;
          visibility:visible;
          opacity:1;
          transition:1s;

      }

      .alertlocationon > div{
          background-color:white;
          padding:1em;
          border-radius:5px;
          border-top:5px solid #B71E0A;
      }
     

      .list > div{
          width:100%;
          margin-bottom:3%;
          border-radius:3px;
          display:grid;
          grid-template-columns:1fr 4fr;
          border:1px solid #B71E0A;
          

      }

      .list > div > .img{
          padding:50%;
      }

      .list > div > div{
        background-position:center;
        background-size:100% 100%;
        background-repeat:no-repeat;
        word-break;
      }

      .list > div > div p{
          text-align:justify;
      }

      .btnMore{

          padding:1% 15%;
          text-decoration:none;
          
          font-size:20px;
          border:none;
          background-color:#F22B11;
          color:white;
      }

      .newComment{
          width:60%;
          background-color:rgba(36, 70, 218, 0.21);
          display:grid;
          grid-template-columns:1fr 7fr;
          border:1px solid #149FF0;
          margin-bottom:1em;
      }

      .newComment > div{
          padding:1%;
      }


      .addcommentoff{
          width:100%;
          padding:15% 30%;
          border-radius:5px;
          box-shadow:0px 2px 2px 0px rgba(0,0,0,0.1);
          height:100%;
          position:fixed;
          top:0;
          left:0;
          background-color:rgba(34, 71, 235, 0.13);
          visibility:hidden;
          opacity:0;
          transition:0.5s;
          z-index:15;
      }

      .addcommentoff > div{
          padding:1em;
          background-color:white;
      }

      .addcommentoff > div > input[type=text]{
          border:none;
          border-bottom:1px solid #2247EB;
          width:100%;
          font-size:18px;
          padding:2%;
          outline:none;
          margin-bottom:1em;
      }

      .addcommentoff > div > textarea{
          width:100%;
          border:1px solid #2247EB;
      }











      .addcommenton{
          width:100%;
          padding:8% 30%;
          border-radius:5px;
          box-shadow:0px 2px 2px 0px rgba(0,0,0,0.1);
          height:100%;
          position:fixed;
          top:0;
          left:0;
          background-color:rgba(34, 71, 235, 0.13);
          visibility:visible;
          opacity:1;
          transition:0.5s;
          z-index:15;
      }

      .addcommenton > div{
          padding:1em;
          background-color:white;
      }

      .addcommenton > div > input[type=text]{
          border:none;
          border-bottom:1px solid #2247EB;
          width:100%;
          font-size:18px;
          padding:2%;
          outline:none;
          margin-bottom:1em;
      }

      .addcommenton > div > textarea{
          width:100%;
          border:1px solid #2247EB;
      }
      

      .btnComment{
        text-align:right;
      }

      .btnComment > button{
          border:none;
          padding:1% 5%;
          color:white;
          
      }

      .btnAddCom{
        width:60%; padding: 2%; background-color:#2247EB; text-align:center; color:white; cursor:pointer;
      }



      /* CSS DISABLED ELEMENT IN PC */
      .pc{
            display:block;
          }

          .mobile{
            display:none;
          }
          



        @media only screen and (max-width: 640px) {
          nav{
            padding:0px;
          }
          .pc{
            display:none;
          }

          .mobile{
            display:block;
          }

          .mob_menuoff{
            position:fixed;
            width:100%;
            height:100vh;
            background-color:rgba(0,0,0,0.5);
            visibility:hidden;
            opacity:0;
            transition:0.5s;
          }

          .mob_menuoff > div{
            position:absolute;
            right:-100%:
            top:0;
            background-color:#090527;
            width:100%;
            height:100%;
            color:white;
          }

          .mob_menuoff > div td{
            font-size:20px;
            text-align:center;
          }


          .mob_menu{
            position:fixed;
            width:100%;
            height:100vh;
            background-color:rgba(0,0,0,0.5);
            visibility:visible;
            opacity:1;
            transition:0.5s;
            z-index:15;
            top:0;
          }

          .mob_menu > div{
            position:absolute;
            right:0:
            top:0;
            background-color:#090527;
            width:100%;
            height:100%;
            color:white;
          }

          .mob_menu > div td{
            font-size:20px;
            text-align:center;
          }

          .mob_menu > div tr{
            border-bottom:1px solid rgba(255,255,255,0.5);
          }

          .mob_menu > div td > i{
            font-size:40px;
            margin-top:7%;
          }

          .close{
            padding:5% 10%;
            margin-top:10%;
            
          }

          .close > i{
            font-size:40px;
            color:white;
          }

          #tagline{
            font-size:20px;
          }

         .btnTop{
           width:50%;
           padding:3%;
           position:fixed;
           left:25%;
           top:87%;
         }





          
        }


        @media only screen and (max-width: 640px) {
            .notifright{
                display:grid;
                grid-template-columns:1fr 1fr 1fr 1fr 1fr;
                top:90%;
                right:12%;
                height:10%;
            }

            .mainAct {
                padding-top:17%;
            }

            .information, .rightInfo, .leftInfo{
                display:grid;
                grid-template-columns:1fr;
            }

            .newComment{
                width:100%;
            }
            
            .btnAddCom{
                width:100%;
            }

            .addcommentoff, .addcommenton{
                padding:10% 5%;
            }

            .alertlocationoff, .alertlocationon{
                padding:10% 5%; 
            }
            
            .list > div{
                display:grid;
                grid-template-columns:1fr;
            }
            
            .list > div > .img{
                padding:20%;
                background-size:70% 100%;
                background-position:center;
            }
        }




      
      

      
      
    </style>
  </head>
  <body>
    <nav>
            <table width='100%' class='mobile'>
                <tr>
                <td style='text-align:left;'><img src="lib/images/TARA GALA LOGO.png" alt="" style='width:30%;' style='float:left;'></td>
                <td width='20%;' onclick='mob_showMenu()'>
                    <i class='large material-icons'>menu</i>
                </td>
                </tr>
            </table>




        <table width='100%' class='pc'>
            <tr>
                <td width='60%' class='logo'><img src="lib/images/TARA GALA LOGO.png" alt="" style='width:10%;'></td>
                <td onclick='window.location.href = "index.php"'>Home</td>
                <td onclick='window.location.href = "mylocation.php"'>My Location</td>
                <td onclick='window.location.href = "topdesti.php"'>Top Destination</td>
                <td onclick='window.location.href = "topviews.php"'>Top Views</td>
            </tr>
        </table>
    </nav>


         <!-- MOBILE -->
    <div class='mobile mob_menuoff' id='mob_menu'>
        <div >
            <div style='padding:5%;'>
                <div style='text-align:center;'>
                <img src="lib/images/TARA GALA LOGO.png" alt="" style='width:60%;'>
                <br>
                <br>
                </div>
                <table width='100%'>
                   <tr>
                    <td width='25%'  ><i class='large material-icons'>home</i></td>
                    <td>Home</td>
                   </tr>

                   <tr onclick='window.location.href = "mylocation.php"'>
                      <td width='25%'><i class='large material-icons'>location_searching</i></td>
                      <td >My Location</td>

                   </tr>

                   <tr onclick='window.location.href = "topdesti.php"'>
                   <td width='25%'><i class='large material-icons'>brightness_high</i></td>
                    <td >Top Destination</td>

                   </tr>

                   <tr onclick='window.location.href = "topviews.php"'>
                   <td width='25%'><i class='large material-icons'>burst_mode</i></td>
                   <td >Top Views</td>

                   </tr>

                   
                </table>

                <div class='close' onclick='mob_close_menu()'>
                   <i class='large material-icons'>chevron_right</i>
                </div>
            </div>
        </div>
    </div>


      <section class='mainAct'>

            <div class='addcommentoff' id='addcomment'>

                <div>
                    New Comment + <br>

                    <input type="text" placeholder='Your name' id='nametxt'><br>
                    <small>Comment</small>
                    <textarea name="" cols="80" rows="5" id='commenttxt'></textarea>

                    <div class='btnComment'>
                        <button style='background-color:#DA2424;' onclick='document.getElementById("addcomment").className="addcommentoff"'>Cancel</button>
                        <button  style='background-color:#2446DA;' onclick='saveComment()'>Save</button>
                    </div>
                </div>
            </div>

            <section class='alertlocationoff' id='alertlocation'>
                <div>
                    <span style='font-size:25px;'>Danger News Baguio</span>
                    <i class='large material-icons' style='float:right;' onclick='document.getElementById("alertlocation").className = "alertlocationoff"'>cancel</i>

                    <div class='list'>
                        <div style='margin-top:3%;'>
                            <div class='img' style='background-image:url("https://s3-ap-northeast-1.amazonaws.com/assets-eaglenews/2018/08/Landslide-and-rockslide-in-Baguio-6.jpg");'></div>
                            <div style='padding:3%;'>
                                <p style='font-size:20px; word-break;'>Landslide-hit roads in Baguio undergo clearing operations   </p>
                                <p>Weather bureau PAGASA said tropical storm "Falcon" is out of the Philippine area of responsibility. But as this report tells, several areas remain flooded and many roads up north are also closed due to landslides. Details from Ron Cruz. - The World Tonight, ANC, July 18, 2019</p>
                            
                                <p style='color:#F22B11;'>ABS-CBN News</p>
                            </div>
                        </div>

                        <div>
                            <div class='img' style=' background-image:url("https://s3-ap-northeast-1.amazonaws.com/assets-eaglenews/2018/08/Landslide-and-rockslide-in-Baguio-6.jpg");'></div>
                            <div style='padding:3%;'>
                                <p style='font-size:20px;'>More casualties reported in Cordillera due to landslide: police  </p>
                                <p>MANILA -- (UPDATE) Twenty people died in the Cordillera region, mostly due to landslides, authorities said Sunday, as they accounted for damage wrought by Typhoon Ompong (Mangkhut).

                                            Seven people died in Benguet, 6 each in Mountain Province and Baguio City, and 1 in Kalinga province, according to a report from Philippine National Police-Cordillera.

                                            Baguio Mayor Mauricio Domogan also reported 6 casualties in his city in an interview on DZMM. Three others were missing, he said.</p>
                            
                                <p style='color:#F22B11;'>ABS-CBN News</p>
                            </div>
                        </div>

                        <div>
                            <div class='img' style='background-image:url("https://s3-ap-northeast-1.amazonaws.com/assets-eaglenews/2018/08/Landslide-and-rockslide-in-Baguio-6.jpg");'></div>
                            <div style='padding:3%;'>
                                <p style='font-size:20px;'>Landslide-hit roads in Baguio undergo clearing operations   </p>
                                <p>Weather bureau PAGASA said tropical storm "Falcon" is out of the Philippine area of responsibility. But as this report tells, several areas remain flooded and many roads up north are also closed due to landslides. Details from Ron Cruz. - The World Tonight, ANC, July 18, 2019</p>
                            
                                <p style='color:#F22B11;'>ABS-CBN News</p>
                            </div>
                        </div>
                    </div>

                    <center>
                        <a class='btnMore' href="https://www.google.com/search?q=baguio+incident+news"'>
                            More..
                        </a>
                    </center>
                </div>  

                
            </section>

            <div class='notifright'>
                <div style='border-top-left-radius:5px; background-color:#F62727;'  onclick='document.getElementById("alertlocation").className = "alertlocationon"'><i class='large material-icons'>assistant_photo</i></div>
                <div style='background-color:#273FF6;'><i class='large material-icons'>sentiment_very_satisfied</i></div>
                <div style='background-color:#F627D7;'><i class='large material-icons'>room_service</i></div>
                <div style='background-color:#0B0613;'><i class='large material-icons'>movie_filter</i></div>
                <div style='border-bottom-left-radius:5px; background-color:#27F6BE;'><i class='large material-icons'>record_voice_over</i></div>
            </div>
           

           <div style='width:100%; height:5%; padding:5%; background-image:url("lib/images/locimages/1111location/main.jpg"); background-position:center; background-repeat:no-repeat; background-size:100%;'>
                
           </div>
           <h2><b style='text-transform:uppercase;'><?php echo $dataLoc['loc_name']; ?> City</b></h2>
           <div class='information'>
                <div style=''>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d61239.98149639836!2d120.55375545668637!3d16.399472401346124!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3391a16879def13f%3A0x8edef534be3a75c0!2sBaguio%2C%20Benguet!5e0!3m2!1sen!2sph!4v1582373077376!5m2!1sen!2sph" width="100%" height="100%" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
                <div style='padding:2% 2% 2% 2%; text-align:justify;'>
                    <p style='font-family:sans-serif, "Tahoma"; '><?php echo $dataLoc['loc_des']; ?></p>
                </div>
           </div>

           <div class='history' '>
               <h2 style='opacity:0.5; font-weight:bold;'>History</h2>
               <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px; background-color:rgba(37, 202, 161, 0.42); padding:5%;'><?php echo $dataLoc['loc_his']; ?></p>
           </div>
           
           <h2 style='opacity:0.5; font-weight:bold;'>Famous Destination</h2>
           <?php 
           $arr = explode('|', $dataLoc['loc_fdes']);
           ?>

            <div class='leftInfo' style='background-color:rgba(37, 202, 92, 0.42); margin-bottom:3%;'>
                            
                    <div style='padding:40%; background-image:url("lib/images/locimages/1111location/fdesimages/BURNHAM PARK.jpg"); '></div>

                    <div style='padding:2%;'>
                        <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px;'><?php echo $arr[0]; ?></p>
                    </div>

            </div>

            <div class='leftInfo' style='background-color:rgba(214, 223, 52, 0.42); margin-bottom:3%;'>
                            
                    <div style='padding:40%; background-image:url("lib/images/locimages/1111location/fdesimages/BAGUIO CATHEDRAL.jpg"); '></div>

                    <div style='padding:2%;'>
                        <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px;'><?php echo $arr[1]; ?></p>
                    </div>

            </div>

            <div class='leftInfo' style='background-color:rgba(214, 223, 52, 0.42); margin-bottom:3%;'>
                            
                    <div style='padding:40%; background-image:url("lib/images/locimages/1111location/fdesimages/MUSEO KORDILYERA.jpg"); '></div>

                    <div style='padding:2%;'>
                        <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px;'><?php echo $arr[2]; ?></p>
                    </div>

            </div>


            <h2 style='opacity:0.5; font-weight:bold;'>Traditions</h2>    
            <?php
            
            $trad = explode('|', $dataLoc['loc_trad']);
            
            ?>

            <div class='rightInfo' style='background-color:rgba(81, 37, 202, 0.42); margin-bottom:3%;'>
                    <div style='padding:2%;'>
                        <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px;'><?php echo $trad[0]; ?></p>
                    </div>
                    <div style='padding:40%; background-image:url("lib/images/locimages/1111location/tradition/MUSEUM.jpg"); '></div>
            </div>

            <div class='rightInfo' style='background-color:rgba(81, 37, 202, 0.42); margin-bottom:3%;'>
                    <div style='padding:2%;'>
                        <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px;'><?php echo $trad[1]; ?></p>
                    </div>
                    <div style='padding:40%; background-image:url("lib/images/locimages/1111location/tradition/FESTIVAL.jpg");'></div>
            </div>
            


            
            <div class='' '>
               <h2 style='opacity:0.5; font-weight:bold;'>Religion</h2>
               <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px; background-color:rgba(37, 202, 161, 0.42); padding:5%;'><?php echo $dataLoc['loc_rel']; ?></p>
            </div>
            
            

            <div class=''>
               <h2 style='opacity:0.5; font-weight:bold;'>Language Used</h2>
               <p style='font-family:sans-serif, "Tahoma"; text-align:justify; line-height:20px; background-color:rgba(37, 202, 161, 0.42); padding:5%;'><?php echo $dataLoc['loc_lan']; ?></p>
            </div>
            
                    <hr>
            <h3>Comments ( <span></span> ) </h3> 
            <?php echo $command->showCommment($_GET['loc']); ?>
            <div onclick='addComment()' class='btnAddCom'>
                ADD COMMENT +
            </div>
            

            <div style='height:50vh;'>
                    
            </div>
      </section>
      
      <script>

        window.onload = function(){
            alert("<?php echo $command->newViewer($_GET['loc']); ?>")
        }
        var addcomment = document.getElementById('addcomment')
        var nametxt = document.getElementById('nametxt')
        var commenttxt = document.getElementById('commenttxt')
        function addComment(){
            addcomment.className = 'addcommenton'
        }

        function saveComment(){
            if(commenttxt.value == ""){

            }else{
                $.ajax({
                    url:'command/saveComment.php',
                    type:'POST',
                    data:{
                        name: nametxt.value,
                        comment: commenttxt.value,
                        commentto:'<?php echo $_GET['loc']; ?>'
                    },
                    success:function(res){
                        
                        if(res == 'true'){
                            window.location.href = ''
                        }else{
                            alert("Something wrong.")
                        }
                        
                    }
                })
            }
        }


        var tagline = document.getElementById('tagline')
        var mob_menu = document.getElementById('mob_menu')
        function mob_showMenu(){
            mob_menu.className = 'mob_menu'
        }

        function mob_close_menu(){
            mob_menu.className = 'mob_menuoff'
        }
    </script>

    
  </body>
  </html>