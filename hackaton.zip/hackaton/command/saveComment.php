<?php

    include_once '../class/autoload.php';

    if(isset($_POST['name']) AND isset($_POST['comment']) AND !empty($_POST['name']) AND !empty($_POST['comment'])){
        echo adminCommand::saveComment($_POST['name'], $_POST['comment'], $_POST['commentto'], new adminCommand);
    }

?>