<!DOCTYPE html>
<html>
  <head>
    <title>Geolocation</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Bangers|Open+Sans+Condensed:300|Saira+Stencil+One|Varela+Round&display=swap" rel="stylesheet">

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 0%;
      }
      /* Optional: Makes the sample page fill the window. */

      html, body {
        height: 100%;
        margin: 0px;
        padding: 0px;
        font-family: 'Open Sans Condensed', sans-serif;
      }

      nav{
          width:100%;
          box-shadow:0px 5px 10px 0px rgba(0,0,0,0.1);
          padding:0px 10%;
          position:fixed;
          top:0;
          left:0;
          background-color:white;
      }

      nav > table td{
          padding:10px;
          
          transition:0px;
      }
      nav > table td:not(.logo){
          text-align:center;
          cursor:pointer;
          -webkit-box-sizing: border-box;
          
      }
      nav > .pc td:not(.logo):hover{
        transition:0px;
        background-color:rgba(75, 111, 240, 0.57);
        color:white;
        border-bottom:3px solid #4B6FF0;
      }

      section{
          padding:0px 10%;
      }

      .mainAct{
        width:100%;
        height:100vh;
        /* border:1px solid red; */
        margin-top:5%;
        margin-bottom:40%;
      }
      
















      .searchLoc{
          display:grid;
          grid-template-columns:1fr 5fr;
          width: 100%;
          margin-bottom:3%;
          box-shadow:0px 2px 2px 0px rgba(0,0,0,0.1);
      }

      .searchLoc input[type=text]{
          width:100%;
          height:100%;
          font-size:20px;
          border:none;
          outline:none;
          background-color:transparent;
      }

      .btnFind{
          background-color:#4A6EF1;
          width:100%;
          padding:1%;
          color:white;

          border:none;
          font-size:20px;
          
          border-radius:3px;
          box-shadow:0px 5px 10px 0px rgba(75, 111, 240, 0.57);
          

      }

      .halfer{
          display:grid;
          margin-top:3%;
          grid-template-columns:1fr 1fr;
          width:100%;
          
      }

      .hint{
          border:2px solid #3461DF;
          border-radius:3px;
          padding:3%;
          width:95%;
          background-color:rgba(52, 97, 223, 0.23);
      }












      /* CSS DISABLED ELEMENT IN PC */
      .pc{
            display:block;
          }

          .mobile{
            display:none;
          }
          



        @media only screen and (max-width: 640px) {
          nav{
            padding:0px;
          }
          .pc{
            display:none;
          }

          .mobile{
            display:block;
          }

          .mob_menuoff{
            position:fixed;
            width:100%;
            height:100vh;
            background-color:rgba(0,0,0,0.5);
            visibility:hidden;
            opacity:0;
            transition:0.5s;
          }

          .mob_menuoff > div{
            position:absolute;
            right:-100%:
            top:0;
            background-color:#090527;
            width:100%;
            height:100%;
            color:white;
          }

          .mob_menuoff > div td{
            font-size:20px;
            text-align:center;
          }


          .mob_menu{
            position:fixed;
            width:100%;
            height:100vh;
            background-color:rgba(0,0,0,0.5);
            visibility:visible;
            opacity:1;
            transition:0.5s;
            z-index:15;
            top:0;
          }

          .mob_menu > div{
            position:absolute;
            right:0:
            top:0;
            background-color:#090527;
            width:100%;
            height:100%;
            color:white;
          }

          .mob_menu > div td{
            font-size:20px;
            text-align:center;
          }

          .mob_menu > div tr{
            border-bottom:1px solid rgba(255,255,255,0.5);
          }

          .mob_menu > div td > i{
            font-size:40px;
            margin-top:7%;
          }

          .close{
            padding:5% 10%;
            margin-top:10%;
            
          }

          .close > i{
            font-size:40px;
            color:white;
          }

          #tagline{
            font-size:20px;
          }

         .btnTop{
           width:50%;
           padding:3%;
           position:fixed;
           left:25%;
           top:87%;
         }
         
         /* SEPERATE */

         .halfer{
            display:grid;
            grid-template-columns:1fr;
         }

         .mainAct{
             padding-top:20%;
         }



          
        }
    </style>
  </head>
  <body>
  <nav>


<table width='100%' class='mobile'>
    <tr>
      <td style='text-align:left;'><img src="lib/images/TARA GALA LOGO.png" alt="" style='width:30%;' style='float:left;'></td>
      <td width='20%;' onclick='mob_showMenu()'>
        <i class='large material-icons'>menu</i>
      </td>
    </tr>
</table>




<table width='100%' class='pc'>
    <tr>
        <td width='60%' class='logo'><img src="lib/images/TARA GALA LOGO.png" alt="" style='width:10%;'></td>
        <td onclick='window.location.href = "index.php"'>Home</td>
        <td onclick='window.location.href = "mylocation.php"'>My Location</td>
        <td onclick='window.location.href = "topdesti.php"'>Top Destination</td>
        <td onclick='window.location.href = "topviews.php"'>Top Views</td>
    </tr>
</table>





</nav>



<!-- MOBILE -->
<div class='mobile mob_menuoff' id='mob_menu'>
<div >
    <div style='padding:5%;'>
        <div style='text-align:center;'>
        <img src="lib/images/TARA GALA LOGO.png" alt="" style='width:60%;'>
        <br>
        <br>
        </div>
        <table width='100%'>
                   <tr>
                    <td width='25%'  ><i class='large material-icons'>home</i></td>
                    <td>Home</td>
                   </tr>

                   <tr onclick='window.location.href = "mylocation.php"'>
                      <td width='25%'><i class='large material-icons'>location_searching</i></td>
                      <td >My Location</td>

                   </tr>

                   <tr onclick='window.location.href = "topdesti.php"'>
                   <td width='25%'><i class='large material-icons'>brightness_high</i></td>
                    <td >Top Destination</td>

                   </tr>

                   <tr onclick='window.location.href = "topviews.php"'>
                   <td width='25%'><i class='large material-icons'>burst_mode</i></td>
                   <td >Top Views</td>

                   </tr>

                   
                </table>

        <div class='close' onclick='mob_close_menu()'>
           <i class='large material-icons'>chevron_right</i>
        </div>
    </div>
</div>
</div>
      <section class='mainAct'>
            <center>
                <div>
                    <iframe src="" frameborder="0" width='100%' height="300" id='currentMap' allow="geolocation"></iframe>
                </div>
            </center>

            

            <div class='halfer'>
                <div>
                    <div class='hint'>
                        <h3><b> Press Find Assistant</b></h3> <br> 
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et enim voluptatem repellendus consequuntur quis repudiandae. Et soluta nemo ipsa iusto ab ipsum nulla, labore quasi debitis ea expedita dolorum earum!</p>
                    </div>
                </div>

                <div>
                    <div>
                        <div class='searchLoc' id='searchLoc'>
                            <div style='padding:5%; text-align:center; background-image:url("lib/images/LOCATION BAR.png"); background-size:25%; background-position:center; background-repeat:no-repeat; padding:10%;'>
                                <img src="" widht='5%;' alt="">
                            </div>
                            <div>
                                <input type="text" placeholder='Enter your place or location' id='findtxt'>
                            </div>
                        </div>


                        <button class='btnFind' id='findbtn'> FIND </button>
                    </div>
                </div>
            </div>
      </section>

      <script>
        if (navigator.geolocation) {
            var timeoutVal = 10 * 1000 * 1000;
            navigator.geolocation.getCurrentPosition(
                displayPosition, 
                displayError,
                { enableHighAccuracy: true, timeout: timeoutVal, maximumAge: 0 }
            );
        }
        else {
            alert("Geolocation is not supported by this browser");
        }

        function displayError(error) {
            var errors = { 
                1: 'Permission denied',
                2: 'Position unavailable',
                3: 'Request timeout'
            };
            alert("Error: " + errors[error.code]);
        }

        function displayPosition(position) {
            var coords = position.coords.latitude +","+position.coords.longitude
            document.getElementById('currentMap').setAttribute('src', "https://maps.google.co.uk/?q=" +coords + "&z=100&output=embed")
        }

        var findbtn = document.getElementById('findbtn')
        var findtxt = document.getElementById('findtxt')
        var searchLoc = document.getElementById('searchLoc')
        findbtn.onclick = function(){
            window.location.href = 'location.php?loc='+1
        }


        var tagline = document.getElementById('tagline')
        var mob_menu = document.getElementById('mob_menu')
        function mob_showMenu(){
            mob_menu.className = 'mob_menu'
        }

        function mob_close_menu(){
            mob_menu.className = 'mob_menuoff'
        }
      </script>
  </body>

  </html>