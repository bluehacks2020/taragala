<?php 

include_once 'class/adminCommand.php';

$command = new adminCommand;
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Geolocation</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Bangers|Open+Sans+Condensed:300|Saira+Stencil+One|Varela+Round&display=swap" rel="stylesheet">

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 0%;
      }
      /* Optional: Makes the sample page fill the window. */

      html, body {
        height: 100%;
        margin: 0px;
        padding: 0px;
        font-family: 'Open Sans Condensed', sans-serif;
      }

      nav{
          width:100%;
          box-shadow:0px 5px 10px 0px rgba(0,0,0,0.1);
          padding:0px 10%;
          position:fixed;
          top:0;
          left:0;
          background-color:white;
      }

      nav > table td{
          padding:10px;
          
          transition:0px;
      }
      nav > table td:not(.logo){
          text-align:center;
          cursor:pointer;
          -webkit-box-sizing: border-box;
          
      }
      nav > table td:not(.logo):hover{
        transition:0px;
        background-color:rgba(75, 111, 240, 0.57);
        color:white;
        border-bottom:3px solid #4B6FF0;
      }

      .mainAct{
        padding:0px 10%;
        width:100%;
        height:100vh;
        /* border:1px solid red; */
        margin-top:5%;
        margin-bottom:40%;
        
      }

      .divtopviews{
          
          display:grid;
          grid-template-columns:2fr 1fr;
          
      }

      .divtopviews > div{
        
        padding:3% 0px;
      }





      #toplist > div{
          width:100%;
          border-radius:5px;
          border:1px solid #3251DC;
          background-color:rgba(50, 81, 220, 0.21);
          display:grid;
          grid-template-columns:1fr 3fr;
          margin-bottom:5%;
      }

      

      #toplist > div > div > .img{
          width:80%;
          padding:40%;
          height:40%;
          margin:10%;
          border-radius:50%;
          background-size:100% 100%;
          background-position:center;
          background-repeat:no-repeat;
      }

      
      
    </style>
  </head>
  <body>
    
    <nav>
        <table width='100%' >
            <tr>
                <td width='60%' class='logo'><img src="lib/images/TARA GALA LOGO.png" alt="" style='width:10%;'></td>
                <td onclick='window.location.href = "index.php"'>Home</td>
                <td onclick='window.location.href = "mylocation.php"'>My Location</td>
                <td>Top Destination</td>
                <td>Top Views</td>
            </tr>
        </table>
    </nav>
    <section class='mainAct'>
        <div class='divtopviews'>
            <div></div>
            <div id='toplist'>
                <?php $command->getHighestlist(); ?>

                
            </div>
        </div>
    </section>

    <script>

    </script>
 </body>

</html>