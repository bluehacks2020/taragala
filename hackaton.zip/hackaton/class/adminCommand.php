<?php 

    class adminCommand{
        private $host = 'localhost';
        private $user = 'root';
        private $pass = '';
        private $dbname = 'taragaladb';
        private $id_terminal;
        
        public $conn;

        function __construct(){
            date_default_timezone_set("Asia/Manila");
        }

        public static function fullDataTopList($self){

        }
        protected function connect(){
            $dsn= "mysql:host=$this->host;dbname=$this->dbname";
            try{	
                return $this->conn = new PDO($dsn, $this->user, $this->pass);
            }catch (PDOException $e){
                header('Location:?error=connectionError');
            }
        }

        public function getListTop(){
            $q_getlist = $this->connect()->prepare("SELECT * FROM locations");
            $q_getlist->execute();
            
            $res = array();
            while($rowTopList = $q_getlist->fetch()){
                // $current = array(
                //     "id" =>         $rowTopList["id"],
                //     "loc_name" =>   $rowTopList["loc_name"],
                //     "loc_img" =>    $rowTopList["loc_img"],
                //     "id_json" =>    $rowTopList["id_json"],
                //     "loc_lan" =>    $rowTopList["loc_lan"],
                //     "loc_rating" => $rowTopList["loc_rating"],
                //     "loc_views" =>  $rowTopList["loc_views"],
                //     "loc_des" =>    $rowTopList["loc_des"],
                //     "loc_his" =>    $rowTopList["loc_his"],
                    
                // );
                ?>
                
                    <div>
                        <div style='border-top-left-radius:5px; border-top-right-radius:5px; background-image:url("lib/images/3_bg.jpeg"); background-color:#f2f2f2; padding:40%;'>
                            
                        </div>
                        <div style='padding:10%;'>
                            <table width='100%' >
                                <tr>
                                    <td width='60%'><span style='font-size:25px;'> <?php echo $rowTopList["loc_name"]; ?> City</span></td>
                                    <td></td>
                                </tr>

                                <tr>
                                    <td width='60%'><button class='btnView' onclick="showTopDes('<?php echo $rowTopList['id']; ?>')">View</button></td>
                                    <td style='text-align:right; opacity:0.5;'>Rating (<b><?php echo $rowTopList["loc_views"]; ?></b>)</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                <?php 
            }
            
        }

        public static function getLocData($id, $self){
            $q_locdata = $self->connect()->prepare("SELECT * FROM locations WHERE id=".$id);
            $q_locdata->execute();
            $arr = array();
            $row = $q_locdata->fetch();
            $arr['loc_name'] = $row['loc_name'];
            $arr['loc_img'] = $row['loc_img'];
            $arr['id_json'] = $row['id_json'];
            $arr['loc_lan'] = $row['loc_lan'];
            $arr['loc_rating'] = $row['loc_rating'];
            $arr['loc_views'] = $row['loc_views'];
            $arr['loc_des'] = $row['loc_des'];
            $arr['loc_his'] = $row['loc_his'];
            $arr['loc_trad'] = $row['loc_trad'];
            $arr['loc_rel'] = $row['loc_rel'];
            $arr['loc_fdes'] = $row['loc_fdes'];
            $arr['views'] = $row['views'];
            $arr['rate'] = $row['rate'];
            
            return $arr;
        }

        public static function saveComment($name, $comment, $comTo, $self){
            $q_insert_comment = $self->connect()->prepare("INSERT INTO reviews (name,date,comment,commentedto)VALUES('$name', '".date("l jS \of F Y h:i:s A")."','$comment',$comTo)");
            if($q_insert_comment->execute() > 0){
                return 'true';
            }else{
                return 'false';
            }
        }

        public function showCommment($loc){
            $q_show_comment = $this->connect()->prepare("SELECT * FROM reviews WHERE commentedto=".$loc);
            $q_show_comment->execute();

            while($row = $q_show_comment->fetch()){
                ?>
            
                    <div class='newComment'>
                        <div >
                            <center><img style='margin-top:15px;' src="https://cdn.onlinewebfonts.com/svg/img_51277.png" alt="" width='50%'></center>
                        </div>
                        <div>
                            <h4><?php echo $row['name']; ?></h4>

                            <p><?php echo $row['comment']; ?></p>
                            <small><?php echo $row['date']; ?></small>
                        </div>
                    </div>
                <?php
            }
             
        }

        public function newViewer($loc){
            $q_newviewer = $this->connect()->prepare("UPDATE locations SET views = views + 1");
            if($q_newviewer->execute() > 0){
                return "Access detected";
            }else{
                return "Denied";
            }
        }

        public function getHighestlist(){
            $q_toplist = $this->connect()->prepare("SELECT *, (SELECT MAX(views) FROM locations) as una, (SELECT MAX(views) FROM locations WHERE views<>una ) as pangalawa, (SELECT MAX(views) FROM locations WHERE views<>una and views<>pangalawa ) as pangatlo  FROM locations");
            $q_toplist->execute();

            while($row = $q_toplist->fetch()){
                ?>
            
                    <div>
                        <div >
                            <div class='img' style='background-image:url("lib/images/locimages/1111location/main.jpg");'>

                            </div>
                        </div>
                        <div>
                            <h3><?php echo $row['loc_name']; ?> City</h3>
                            <p style=' width:90%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>views <b><?php echo $row['views']; ?></b></p>
                        </div>
                        
                    </div>
               <?php
            }
             
        }
    }   
    
?>