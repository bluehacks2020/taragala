<?php 


    include_once 'adminCommand.php';
?>